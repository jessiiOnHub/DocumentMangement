using DocumentManagement.Features.Data;
using DocumentManagement.Features.Data.Models;
using DocumentManagement.Features.Repositories.Interfaces;
using Microsoft.EntityFrameworkCore;

namespace DocumentManagement.Features.Repositories.Implementations
{
    public class DocumentRepository : IDocumentRepository
    {
        private readonly AppDbContext _context;

        public DocumentRepository(AppDbContext context)
        {
            _context = context;
        }

        public async Task<List<Document>> GetAllAsync() =>
            await _context.Documents.Include(d => d.UploadedBy).ToListAsync();

        public async Task<Document?> GetByIdAsync(int id) =>
            await _context.Documents.Include(d => d.UploadedBy).FirstOrDefaultAsync(d => d.Id == id);

        public async Task<List<Document>> GetByUserIdAsync(int userId) =>
            await _context.Documents
                .Include(d => d.UploadedBy)
                .Where(d => d.UploadedByUserId == userId)
                .ToListAsync();

        public async Task AddAsync(Document document)
        {
            _context.Documents.Add(document);
            await _context.SaveChangesAsync();
        }

        public async Task UpdateAsync(Document document)
        {
            document.UpdatedAt = DateTime.UtcNow;
            _context.Documents.Update(document);
            await _context.SaveChangesAsync();
        }

        public async Task DeleteAsync(int id)
        {
            var doc = await _context.Documents.FindAsync(id);
            if (doc == null) return;
            _context.Documents.Remove(doc);
            await _context.SaveChangesAsync();
        }
    }
}
