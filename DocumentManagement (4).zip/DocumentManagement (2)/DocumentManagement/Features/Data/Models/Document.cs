using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace DocumentManagement.Features.Data.Models
{
    public class Document : BaseModel
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Id { get; set; }

        [Required, MaxLength(200)]
        public string Title { get; set; } = string.Empty;

        [MaxLength(500)]
        public string Description { get; set; } = string.Empty; 

        [Required, MaxLength(100)]
        public string Category { get; set; } = string.Empty;

        [Required, MaxLength(255)]
        public string FileName { get; set; } = string.Empty;

        [Required, MaxLength(50)]
        public string FileType { get; set; } = string.Empty;

        public long FileSizeBytes { get; set; }

        [Required, MaxLength(50)]
        public string Status { get; set; } = "Active"; // Active, Archived, Draft

        public byte[]? Content { get; set; }

        public int UploadedByUserId { get; set; }

        [ForeignKey("UploadedByUserId")]
        public User? UploadedBy { get; set; }
    }
}
