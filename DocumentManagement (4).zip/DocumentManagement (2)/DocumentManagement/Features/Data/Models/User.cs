using DocumentManagement.Features.Data.Enums;
using System.ComponentModel.DataAnnotations;

namespace DocumentManagement.Features.Data.Models
{
    public class User : BaseModel
    {
        [Key]
        public int Id { get; set; }

        [Required, MaxLength(100)]
        public string Name { get; set; } = string.Empty;

        [Required, MaxLength(100), EmailAddress]
        public string Email { get; set; } = string.Empty;

        [Required, MaxLength(50)]
        public string Username { get; set; } = string.Empty;

        [Required, MaxLength(255)]
        public string Password { get; set; } = string.Empty;

        public UserRole Role { get; set; } = UserRole.Student;

        // Navigation
        public ICollection<Document> Documents { get; set; } = new List<Document>();
    }
}
