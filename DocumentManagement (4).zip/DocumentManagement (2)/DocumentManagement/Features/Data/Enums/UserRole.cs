namespace DocumentManagement.Features.Data.Enums
{
    public enum UserRole
    {
        LibraryAdmin = 1,
        Student = 2
    }
}
