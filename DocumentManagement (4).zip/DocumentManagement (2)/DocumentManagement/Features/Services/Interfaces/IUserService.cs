using DocumentManagement.Features.Data.Models;
using DocumentManagement.Features.Services.Models;

namespace DocumentManagement.Features.Services.Interfaces
{
    
    public interface IUserService
    {
        
        Task<List<User>> GetAllUsersAsync();

       
        /// <param name="id"
        Task<User?> GetUserByIdAsync(int id);


        /// <param name="username"
        /// <param name="password"
        
        Task<User?> LoginAsync(string username, string password);

       
        /// <param name="user"
        /// <exception cref="Exception"
        Task RegisterAsync(User user);

        
        /// <param name="user"
        Task UpdateUserAsync(User user);

        
        /// <param name="request"
      
        Task<UserUpdateResult> UpdateUserInfoAsync(UserUpdateRequest request);

        
        /// <param name="id">
        Task DeleteUserAsync(int id);
    }
}
