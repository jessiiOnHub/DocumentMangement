using System.IO;
using DocumentManagement.Features.Data.Models;

namespace DocumentManagement.Features.Services.Interfaces
{
    public interface IDocumentService
    {
        Task<List<Document>> GetAllDocumentsAsync();
        Task<Document?> GetDocumentByIdAsync(int id);
        Task<List<Document>> GetDocumentsByUserIdAsync(int userId);
        Task CreateDocumentAsync(Document document);
        Task UpdateDocumentAsync(Document document);
        Task DeleteDocumentAsync(int id, string userRole);
        Task SaveDocumentWithFileAsync(Document document, Stream fileStream, string fileName);
        Task<Stream> GetDocumentStreamAsync(int id);
        byte[] ExportToCsv(List<Document> documents);
        Task<int> ImportFromCsvAsync(Stream stream, int userId);
    }
}
