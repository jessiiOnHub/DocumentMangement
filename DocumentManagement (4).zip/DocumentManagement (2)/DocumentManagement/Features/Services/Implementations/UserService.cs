using DocumentManagement.Features.Data.Models;
using DocumentManagement.Features.Repositories.Interfaces;
using DocumentManagement.Features.Services.Interfaces;
using DocumentManagement.Features.Services.Models;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;

namespace DocumentManagement.Features.Services.Implementations
{
    public class UserService : IUserService
    {
        private readonly IUserRepository _repo;

        public UserService(IUserRepository repo)
        {
            _repo = repo;
        }

        public Task<List<User>> GetAllUsersAsync() => _repo.GetAllAsync();

        public Task<User?> GetUserByIdAsync(int id) => _repo.GetByIdAsync(id);

        public async Task<User?> LoginAsync(string username, string password)
        {
            var user = await _repo.GetByUsernameAsync(username);
            if (user == null) return null;
            if (user.Password != Hash(password)) return null;
            return user;
        }

        public async Task RegisterAsync(User user)
        {
            var existing = await _repo.GetByUsernameAsync(user.Username);
            if (existing != null)
                throw new Exception("Username already exists.");

            user.Password = Hash(user.Password);
            await _repo.AddAsync(user);
        }

        public Task UpdateUserAsync(User user) => _repo.UpdateAsync(user);

        public async Task<UserUpdateResult> UpdateUserInfoAsync(UserUpdateRequest request)
        {
            var result = new UserUpdateResult();
            try
            {
                // 1. Identify user by user_id
                var user = await _repo.GetByIdAsync(request.Id);
                if (user == null)
                {
                    result.IsSuccess = false;
                    result.Message = $"User with ID {request.Id} not found.";
                    return result;
                }

                // 2. Validate inputs
                if (request.Email != null)
                {
                    if (string.IsNullOrWhiteSpace(request.Email))
                    {
                        result.IsSuccess = false;
                        result.Message = "Email cannot be empty.";
                        return result;
                    }

                    if (!Regex.IsMatch(request.Email, @"^[^@\s]+@[^@\s]+\.[^@\s]+$"))
                    {
                        result.IsSuccess = false;
                        result.Message = "Invalid email format.";
                        return result;
                    }

                    // 4. Check for duplicate emails
                    var existingEmailUser = await _repo.GetByEmailAsync(request.Email);
                    if (existingEmailUser != null && existingEmailUser.Id != user.Id)
                    {
                        result.IsSuccess = false;
                        result.Message = "Email already in use by another user.";
                        return result;
                    }
                }

                if (request.Name != null && string.IsNullOrWhiteSpace(request.Name))
                {
                    result.IsSuccess = false;
                    result.Message = "Name cannot be empty.";
                    return result;
                }

                if (request.Username != null && string.IsNullOrWhiteSpace(request.Username))
                {
                    result.IsSuccess = false;
                    result.Message = "Username cannot be empty.";
                    return result;
                }

                // 3. Partial update
                if (request.Name != null && user.Name != request.Name)
                {
                    user.Name = request.Name;
                    result.UpdatedFields.Add(nameof(User.Name));
                }

                if (request.Email != null && user.Email != request.Email)
                {
                    user.Email = request.Email;
                    result.UpdatedFields.Add(nameof(User.Email));
                }

                if (request.Username != null && user.Username != request.Username)
                {
                    user.Username = request.Username;
                    result.UpdatedFields.Add(nameof(User.Username));
                }

                if (request.Password != null && !string.IsNullOrWhiteSpace(request.Password))
                {
                    user.Password = Hash(request.Password);
                    result.UpdatedFields.Add(nameof(User.Password));
                }

                if (request.Role != null && user.Role != request.Role.Value)
                {
                    user.Role = request.Role.Value;
                    result.UpdatedFields.Add(nameof(User.Role));
                }

                if (result.UpdatedFields.Count > 0)
                {
                    await _repo.UpdateAsync(user);
                    result.IsSuccess = true;
                    result.Message = "User updated successfully.";
                }
                else
                {
                    result.IsSuccess = true;
                    result.Message = "No changes detected.";
                }
            }
            catch (Exception ex)
            {
                result.IsSuccess = false;
                result.Message = $"An error occurred: {ex.Message}";
            }

            return result;
        }

        public Task DeleteUserAsync(int id) => _repo.DeleteAsync(id);

        private static string Hash(string input)
        {
            using var sha = SHA256.Create();
            return Convert.ToHexString(sha.ComputeHash(Encoding.UTF8.GetBytes(input)));
        }
    }
}
