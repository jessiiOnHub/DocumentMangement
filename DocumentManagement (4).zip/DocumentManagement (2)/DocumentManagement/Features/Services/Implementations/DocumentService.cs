using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Threading.Tasks;
using DocumentManagement.Features.Data.Models;
using DocumentManagement.Features.Repositories.Interfaces;
using DocumentManagement.Features.Services.Interfaces;

namespace DocumentManagement.Features.Services.Implementations
{
    public class DocumentService : IDocumentService
    {
        private readonly IDocumentRepository _repo;
        private readonly string _storagePath;

        public DocumentService(IDocumentRepository repo)
        {
            _repo = repo;
            // XAMPP storage path (typically C:\xampp\htdocs\DocumentStorage)
            _storagePath = @"C:\xampp\htdocs\DocumentStorage";
            if (!Directory.Exists(_storagePath))
            {
                Directory.CreateDirectory(_storagePath);
            }
        }

        public async Task SaveDocumentWithFileAsync(Document document, Stream fileStream, string fileName)
        {
            // Generate unique filename to avoid collisions
            var uniqueFileName = $"{Guid.NewGuid()}_{fileName}";
            var fullPath = Path.Combine(_storagePath, uniqueFileName);

            using (var file = new FileStream(fullPath, FileMode.Create))
            {
                await fileStream.CopyToAsync(file);
            }

            // Save metadata and the relative path in the database
            // We reuse the Content field to store the relative path as bytes, 
            // or better, just use FileName to store the unique path.
            // For now, let's store the path in a way that doesn't break existing logic.
            document.FileName = uniqueFileName; 
            document.Content = null; // Don't store in DB

            if (document.Id == 0)
            {
                await _repo.AddAsync(document);
            }
            else
            {
                await _repo.UpdateAsync(document);
            }
        }

        public async Task<Stream> GetDocumentStreamAsync(int id)
        {
            var doc = await _repo.GetByIdAsync(id);
            if (doc == null) throw new FileNotFoundException("Document not found");

            var fullPath = Path.Combine(_storagePath, doc.FileName);
            if (!File.Exists(fullPath)) throw new FileNotFoundException("Physical file not found");

            return new FileStream(fullPath, FileMode.Open, FileAccess.Read);
        }

        public Task<List<Document>> GetAllDocumentsAsync() => _repo.GetAllAsync();

        public Task<Document?> GetDocumentByIdAsync(int id) => _repo.GetByIdAsync(id);

        public Task<List<Document>> GetDocumentsByUserIdAsync(int userId) => _repo.GetByUserIdAsync(userId);

        public Task CreateDocumentAsync(Document document) => _repo.AddAsync(document);

        public Task UpdateDocumentAsync(Document document) => _repo.UpdateAsync(document);

        public async Task DeleteDocumentAsync(int id, string userRole)
        {
            if (userRole != "LibraryAdmin")
            {
                throw new UnauthorizedAccessException("Only Library Admins are allowed to delete documents.");
            }
            await _repo.DeleteAsync(id);
        }

        public byte[] ExportToCsv(List<Document> documents)
        {
            var builder = new StringBuilder();
            builder.AppendLine("Title,Description,Category,Status,FileName,FileType,FileSizeBytes,CreatedAt,ContentBase64");

            foreach (var doc in documents)
            {
                var contentBase64 = doc.Content != null ? Convert.ToBase64String(doc.Content) : "";
                builder.AppendLine($"\"{EscapeCsv(doc.Title)}\",\"{EscapeCsv(doc.Description)}\",\"{EscapeCsv(doc.Category)}\",\"{EscapeCsv(doc.Status)}\",\"{EscapeCsv(doc.FileName)}\",\"{EscapeCsv(doc.FileType)}\",{doc.FileSizeBytes},\"{doc.CreatedAt:yyyy-MM-dd HH:mm:ss}\",\"{contentBase64}\"");
            }

            return Encoding.UTF8.GetBytes(builder.ToString());
        }

        public async Task<int> ImportFromCsvAsync(Stream stream, int userId)
        {
            using var reader = new StreamReader(stream);
            var headerLine = await reader.ReadLineAsync(); // Skip header
            if (headerLine == null) return 0;

            int importedCount = 0;
            string? line;
            while ((line = await reader.ReadLineAsync()) != null)
            {
                var parts = ParseCsvLine(line);
                if (parts.Count < 6) continue;

                var document = new Document
                {
                    Title = parts[0],
                    Description = parts[1],
                    Category = parts[2],
                    Status = parts[3],
                    FileName = parts[4],
                    FileType = parts[5],
                    FileSizeBytes = parts.Count > 6 && long.TryParse(parts[6], out var size) ? size : 0,
                    UploadedByUserId = userId,
                    CreatedAt = parts.Count > 7 && DateTime.TryParse(parts[7], out var dt) ? dt : DateTime.UtcNow,
                    Content = parts.Count > 8 && !string.IsNullOrEmpty(parts[8]) ? Convert.FromBase64String(parts[8]) : null
                };

                await _repo.AddAsync(document);
                importedCount++;
            }

            return importedCount;
        }

        private string EscapeCsv(string text)
        {
            if (string.IsNullOrEmpty(text)) return "";
            return text.Replace("\"", "\"\"");
        }

        private List<string> ParseCsvLine(string line)
        {
            var result = new List<string>();
            bool inQuotes = false;
            var currentPart = new StringBuilder();

            for (int i = 0; i < line.Length; i++)
            {
                char c = line[i];
                if (c == '\"')
                {
                    if (inQuotes && i + 1 < line.Length && line[i + 1] == '\"')
                    {
                        currentPart.Append('\"');
                        i++;
                    }
                    else
                    {
                        inQuotes = !inQuotes;
                    }
                }
                else if (c == ',' && !inQuotes)
                {
                    result.Add(currentPart.ToString());
                    currentPart.Clear();
                }
                else
                {
                    currentPart.Append(c);
                }
            }
            result.Add(currentPart.ToString());
            return result;
        }
    }
}
