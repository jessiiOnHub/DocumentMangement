using DocumentManagement.Features.Data.Enums;

namespace DocumentManagement.Features.Services.Models
{
    public class UserUpdateRequest
    {
        public int Id { get; set; }
        public string? Name { get; set; }
        public string? Email { get; set; }
        public string? Username { get; set; }
        public string? Password { get; set; }
        public UserRole? Role { get; set; }
    }
}
