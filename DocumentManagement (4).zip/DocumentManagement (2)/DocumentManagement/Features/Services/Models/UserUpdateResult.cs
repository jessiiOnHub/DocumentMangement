using System.Collections.Generic;

namespace DocumentManagement.Features.Services.Models
{
    public class UserUpdateResult
    {
        public bool IsSuccess { get; set; }
        public string? Message { get; set; }
        public List<string> UpdatedFields { get; set; } = new List<string>();
    }
}
