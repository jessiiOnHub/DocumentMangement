using DocumentManagement.Components;
using DocumentManagement.Features.Authentication.Helpers;
using DocumentManagement.Features.Data;
using DocumentManagement.Features.Repositories.Implementations;
using DocumentManagement.Features.Repositories.Interfaces;
using DocumentManagement.Features.Services.Implementations;
using DocumentManagement.Features.Services.Interfaces;
using Microsoft.AspNetCore.Components.Authorization;
using Microsoft.EntityFrameworkCore;
using MudBlazor.Services;

var builder = WebApplication.CreateBuilder(args);

// ── MudBlazor ────────────────────────────────────────────────
builder.Services.AddMudServices();

// ── Blazor ───────────────────────────────────────────────────
builder.Services.AddRazorComponents()
    .AddInteractiveServerComponents();

builder.Services.AddServerSideBlazor().AddHubOptions(o =>
{
    o.MaximumReceiveMessageSize = 512 * 1024 * 1024; // 512MB
});

// ── Database ─────────────────────────────────────────────────
builder.Services.AddDbContext<AppDbContext>(options =>
{
    var connectionString = builder.Configuration.GetConnectionString("DefaultConnection");
    options.UseMySql(connectionString, new MySqlServerVersion(new Version(8, 0, 36)), 
        mySqlOptions => mySqlOptions.EnableRetryOnFailure());
});

// ── Repositories ─────────────────────────────────────────────
builder.Services.AddScoped<IUserRepository,     UserRepository>();
builder.Services.AddScoped<IDocumentRepository, DocumentRepository>();

// ── Services ─────────────────────────────────────────────────
builder.Services.AddScoped<IUserService,     UserService>();
builder.Services.AddScoped<IDocumentService, DocumentService>();

// ── Auth ─────────────────────────────────────────────────────
builder.Services.AddCascadingAuthenticationState();
builder.Services.AddScoped<CustomAuthenticationStateProvider>();
builder.Services.AddScoped<AuthenticationStateProvider>(sp =>
    sp.GetRequiredService<CustomAuthenticationStateProvider>());

builder.Services.AddAuthentication("Cookies")
    .AddCookie("Cookies", options =>
    {
        options.LoginPath = "/login";
    });

builder.Services.AddAuthorization();

// ─────────────────────────────────────────────────────────────
var app = builder.Build();

if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Error", createScopeForErrors: true);
    app.UseHsts();
}

app.UseHttpsRedirection();
app.UseStaticFiles();
app.UseAuthentication();
app.UseAuthorization();
app.UseAntiforgery();

app.MapStaticAssets();
app.MapRazorComponents<App>()
    .AddInteractiveServerRenderMode();

app.Run();
